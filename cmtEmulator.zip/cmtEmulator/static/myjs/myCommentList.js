 $(function () {
        $('[data-toggle="popover"]').popover()
    })
 
 function judgedel() {
     return confirm("此操作不可逆，是否删除？");
 }