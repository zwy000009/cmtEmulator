# -*- coding:utf-8 -*-
import time
import os
def writeLog(func):
    LOG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + '/logs/'
    def wrapper(*args,**kargs):
        logFilePath = LOG_DIR+time.strftime('%Y%m%d',time.localtime(time.time()))+'.log'
        if os.path.exists(logFilePath):
            fp = open(logFilePath,'a')
        else:
            fp = open(logFilePath,'w')
        timenow = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        logs = timenow+" "+func.__name__ + " running...\n"
        fp.write(logs)
        return func(*args,**kargs)
    return wrapper

@writeLog
def testfunc():
    return [1,2,3]

if __name__ == "__main__":
    print testfunc
    pass
