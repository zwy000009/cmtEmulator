# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class myCommentTable(models.Model):
    comment_id = models.CharField(primary_key=True,max_length=50,verbose_name=u'评论编号')
    comment_time = models.DateTimeField(verbose_name=u'评论时间')
    user_email = models.EmailField(verbose_name=u'用户邮箱')
    user_comment = models.CharField(max_length=128,null=True,verbose_name=u'用户评论')