# -*- coding:utf-8 -*-
from apps.commentctl.models import myCommentTable

def getCommentList(keyword=None,pagenum=1):
    pagenum = int(pagenum)
    num_head = (pagenum-1)*10
    num_tail = num_head+10
    objlist_commentlist = myCommentTable.objects.all().order_by('-comment_time')[num_head:num_tail]
    return objlist_commentlist

def getCommentNum(keyword=None):
    return len(myCommentTable.objects.all())

def getPageList(pagenum=1):
    pagenum = int(pagenum)
    preBtn = "hide"
    nexBtn = "hide"
    cmtNum = getCommentNum()
    if cmtNum%10 == 0:
        allPageList = cmtNum/10
    else:
        allPageList = cmtNum/10+1
    if allPageList == 1:
        pagelist = []
    else:
        if pagenum != 1:
            preBtn = "show"
        if pagenum != allPageList:
            nexBtn = "show"
        if allPageList < 7 :
            pagelist = range(1,allPageList+1)
        elif pagenum > 4 :
            if pagenum+3 < allPageList:
                pagelist = range(pagenum-3, pagenum+3)
            else:
                pagelist = range(pagenum - 3, allPageList+1)
        else :
            pagelist = range(1,8)
    dictReturn = {
        'preBtn': preBtn,
        'nexBtn': nexBtn,
        'pagelist': pagelist
    }
    return dictReturn
