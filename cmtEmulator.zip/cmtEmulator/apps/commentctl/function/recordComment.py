# -*- coding:utf-8 -*-
from apps.commentctl.models import myCommentTable
import hashlib
import time

def writeCmtIntoDB(dict_info):
    comment_id = idGenerator()
    comment_time = getDatatime()
    obj_cmttab = myCommentTable()
    obj_cmttab.comment_id = comment_id
    obj_cmttab.comment_time = comment_time
    obj_cmttab.user_email = dict_info['usermail']
    obj_cmttab.user_comment = dict_info['usercomment']
    obj_cmttab.save()

def idGenerator():
    str_time = str(time.time())
    hash_time = hashlib.md5()
    hash_time.update(str_time)
    uniqueID = hash_time.hexdigest()
    return uniqueID

def getDatatime():
    return time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))


