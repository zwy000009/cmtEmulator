# -*- coding:utf-8 -*-
from apps.commentctl.models import myCommentTable


def delComment(comment_id):
    myCommentTable.objects.get(comment_id=comment_id).delete()
