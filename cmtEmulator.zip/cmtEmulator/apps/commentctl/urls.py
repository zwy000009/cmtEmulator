from django.conf.urls import url
import views as commentviews

urlpatterns = [
    url(r'^$', commentviews.commentPage,name='commentIndex'),
    url(r'^success/$',commentviews.commentSuccess,name='commentSuccess'),
    url(r'^list/',commentviews.commentListPage,name='commentList'),
]