# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from function.recordComment import writeCmtIntoDB
from function.getCommentList import getCommentList,getPageList
from function.delComment import delComment

# Create your views here.


def commentPage(request):
    if request.method == "POST":
        str_userMail = request.POST.get('userMail',None)
        str_userComment = request.POST.get('userComment',None)
        dict_userinfo = {
            'usermail':str_userMail,
            'usercomment':str_userComment,
        }
        writeCmtIntoDB(dict_userinfo)
        return HttpResponseRedirect(reverse(commentSuccess))
    return render(request,'commentctl/myCommentPage.html')

def commentSuccess(request):
    return render(request,'commentctl/reactionSuccess.html')

def commentListPage(request):
    pagenum = request.GET.get('pagenum',None)
    if pagenum == None:
        pagenum = 1
    pagenum = int(pagenum)
    pagedict = getPageList(pagenum)
    commentlist = getCommentList(pagenum=pagenum)
    if request.method=="POST":
        id_comment = request.POST.get('delcommentid',None)
        delComment(id_comment)
        return HttpResponseRedirect(reverse(commentListPage)+"?pagenum="+str(pagenum))
    dict_clpreturn = {
        'commentlist':commentlist,
        'pagedict':pagedict,
        'prenum':pagenum-1,
        'nexnum':pagenum+1,
    }
    return render(request,'commentctl/myCommentList.html',dict_clpreturn)